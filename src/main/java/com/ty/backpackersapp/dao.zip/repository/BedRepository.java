package com.ty.backpackersapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.backpackersapp.dto.Bed;

public interface BedRepository extends JpaRepository<Bed, Integer> {

}
